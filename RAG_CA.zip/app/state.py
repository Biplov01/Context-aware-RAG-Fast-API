from typing import List
from typing_extensions import TypedDict

class ChatState(TypedDict):
    chat_history: List[dict]   # full chat memory
    retrieved_context: str
