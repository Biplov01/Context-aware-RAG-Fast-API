import os
import faiss
import numpy as np
from PyPDF2 import PdfReader
from sentence_transformers import SentenceTransformer

PDF_DIR = "data/pdfs"

embedder = SentenceTransformer("all-MiniLM-L6-v2")
chunks = []

def read_pdf(path):
    reader = PdfReader(path)
    text = ""
    for page in reader.pages:
        if page.extract_text():
            text += page.extract_text() + "\n"
    return text

def chunk_text(text, size=500, overlap=50):
    parts = []
    i = 0
    while i < len(text):
        parts.append(text[i:i+size])
        i += size - overlap
    return parts

for file in os.listdir(PDF_DIR):
    if file.endswith(".pdf"):
        text = read_pdf(os.path.join(PDF_DIR, file))
        chunks.extend(chunk_text(text))

embeddings = embedder.encode(chunks)
index = faiss.IndexFlatL2(embeddings.shape[1])
index.add(np.array(embeddings))

def retrieve(query, k=4):
    q_emb = embedder.encode([query])
    _, idx = index.search(np.array(q_emb), k)
    return [chunks[i] for i in idx[0]]
