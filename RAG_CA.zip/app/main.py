from fastapi import FastAPI
from pydantic import BaseModel
from app.graph import build_graph

app = FastAPI(title="Context-Aware RAG Chatbot")
from fastapi.middleware.cors import CORSMiddleware

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # allow all origins
    allow_credentials=True,
    allow_methods=["*"],  # allow POST, GET, OPTIONS, etc.
    allow_headers=["*"],
)

graph = build_graph()
sessions = {}

class ChatRequest(BaseModel):
    session_id: str
    query: str

@app.post("/chat")
def chat(req: ChatRequest):
    if req.session_id not in sessions:
        sessions[req.session_id] = []

    sessions[req.session_id].append(
        {"role": "user", "content": req.query}
    )

    result = graph.invoke({
        "chat_history": sessions[req.session_id],
        "retrieved_context": ""
    })

    sessions[req.session_id] = result["chat_history"]

    return {"answer": result["chat_history"][-1]["content"]}
