from langgraph.graph import StateGraph, END
from app.state import ChatState
from app.retriever import retrieve
from app.llm import call_ollama

# -------- NODE 1: Context-Aware Retrieval --------
def retrieval_node(state: ChatState):
    """
    Uses full conversation history to form
    a better retrieval query
    """
    last_user_message = state["chat_history"][-1]["content"]

    # Build a conversational query
    conversation_context = "\n".join(
        [m["content"] for m in state["chat_history"][-5:]]
    )

    retrieval_query = f"""
Conversation so far:
{conversation_context}

User question:
{last_user_message}
"""

    docs = retrieve(retrieval_query)
    context = "\n\n".join(docs)

    return {
        "retrieved_context": context,
        "chat_history": state["chat_history"]
    }

# -------- NODE 2: Context-Aware Generation --------
def generation_node(state: ChatState):
    messages = [
        {"role": "system", "content": 
         "Use the following context and conversation history to answer accurately."},
        {"role": "system", "content": state["retrieved_context"]},
    ]

    # Append entire chat history
    messages.extend(state["chat_history"])

    answer = call_ollama(messages)

    state["chat_history"].append(
        {"role": "assistant", "content": answer}
    )

    return {
        "chat_history": state["chat_history"],
        "retrieved_context": state["retrieved_context"]
    }

def build_graph():
    graph = StateGraph(ChatState)

    graph.add_node("retrieve", retrieval_node)
    graph.add_node("generate", generation_node)

    graph.set_entry_point("retrieve")
    graph.add_edge("retrieve", "generate")
    graph.add_edge("generate", END)

    return graph.compile()
